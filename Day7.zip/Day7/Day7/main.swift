//
//  main.swift
//  Day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var j = PermanentEmp(empID: 110, empName: "Jasmeet", basicPay: 40200.00, holiday: 4)
j.display()

var r = TempEmp(empID: 111, empName: "Ravinder", basicPay: 10000.00, holiday: 24)
r.display()

print(12344.56)
print(12_344.56)
print(1_2344.56.asCurrency)

print("7 is a prime number? \(7.isPrime)")
print("1 is a prime number? \(1.isPrime)")
print("12 is a prime number? \(12.isPrime)")

3.wish {
    print("Happy birthday Jasmeet")
}

print(1837493[3])
