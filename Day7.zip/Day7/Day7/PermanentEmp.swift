//
//  PermanentEmp.swift
//  Day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class PermanentEmp : Employee, INetPay{
    
    
    var weeks : Int?
    
    //Get only compueted property
    var netPay : Double?{
        get{
            if self.weeks! > 3{
                return self.basicPay! - 100
            }else{
                return self.basicPay!
            }
        }
    }
    
    override init() {
        self.weeks = 0
        //self.netPay = 0.0
        super.init()
    }
    
    //Requred initializer protocol
    required init(empID: Int, empName: String, basicPay: Double, holiday: Int) {
        self.weeks = holiday
        super.init(empID: empID, empName: empName, basicPay: basicPay)
    }
    
    override func display() {
        super.display()
        print("Weeks : \(self.weeks ?? 0)")
        print("Net pay: \(self.netPay ?? self.basicPay ?? 0.0)")
    }
}
