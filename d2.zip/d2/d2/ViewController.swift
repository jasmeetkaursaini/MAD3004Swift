//
//  ViewController.swift
//  d2
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var lblDisplay: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func btnLogin(_ sender: Any) {
          let clickedButton = sender as! UIButton
        if clickedButton.tag == 1 {
//            btnRegister.isHidden = false
//            btnLogin.isHidden = true
        }
        
//        let name = "Jasmeet"
//        let password = "Saini"
//
//        if txtName.text == name && txtPassword.text == password
//        {
//            lblDisplay.text = "Login Successful"
//        }
//        else
//        {
//            lblDisplay.text = "Login Unsuccessful"
//        }
        
        //lblDisplay.text = txtName.text
    }
    
    @IBAction func btnRegister(_ sender: Any) {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

