//
//  ViewController.swift
//  OddEven
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var n : Int = 0
    
    @IBOutlet weak var lblNumber: UILabel!
    
    @IBOutlet weak var imgNumber: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        n = Int(arc4random_uniform(100))
        lblNumber.text = "\(n)"
        print(n)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func btnOdd(_ sender: Any) {
        if n % 2 != 0 {
            imgNumber.image = UIImage(named: "Right")
            let alertController = UIAlertController(title: "Result", message: "Hurryy.. Correct Answer!", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "Play again!", style: .default, handler: {_ in self.viewDidLoad()})
            let defaultAction1 = UIAlertAction(title: "Show Progress", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            alertController.addAction(defaultAction1)
            present(alertController, animated: true, completion: nil)
        }
        else{
            imgNumber.image = UIImage(named: "Wrong")
            let alertController = UIAlertController(title: "Result", message: "Oppps... Wrong Answer.. Correct Answer is Even!", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "Play again!", style: .default, handler: {_ in self.viewDidLoad()})
            let defaultAction1 = UIAlertAction(title: "Show Progress", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            alertController.addAction(defaultAction1)
            present(alertController, animated: true, completion: nil)
        }
    }
    
    
    @IBAction func btnEven(_ sender: Any) {
        if n % 2 == 0 {
            imgNumber.image = UIImage(named: "Right")
            let alertController = UIAlertController(title: "Result", message: "Hurryy.. Correct Answer!", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "Play again!", style: .default, handler: {_ in self.viewDidLoad()})
            let defaultAction1 = UIAlertAction(title: "Show Progress", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            alertController.addAction(defaultAction1)
            present(alertController, animated: true, completion: nil)
        }
        else{
            imgNumber.image = UIImage(named: "Wrong")
            imgNumber.image = UIImage(named: "Wrong")
            let alertController = UIAlertController(title: "Result", message: "Oppps... Wrong Answer.. Correct Answer is Odd!", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "Play again!", style: .default, handler: {_ in self.viewDidLoad()})
            let defaultAction1 = UIAlertAction(title: "Show Progress", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            alertController.addAction(defaultAction1)
            present(alertController, animated: true, completion: nil)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadPage() {
        super.viewDidLoad()
    }


}

