//
//  main.swift
//  AirlinesProject
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var choice = 1

while choice != 6{
    print("\n....We never forget you have a choice.")
    print("\t 1 : Inquery of Plane Type")
    print("\t 2 : Inquery of Airplane Type")
    print("\t 3 : Display employeers")
    print("\t 4 : Show schedules")
    print("\t 5 : Book reservation")
    print("\t 6 : Update reservation")
    print("\t 7 : Cancel reservation")
    print("\t 8 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
        default:
        print("Please emter valid menu option.")
    }
}

