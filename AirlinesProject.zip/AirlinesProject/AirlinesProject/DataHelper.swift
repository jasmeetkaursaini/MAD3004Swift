//
//  DataHelper.swift
//  AirlinesProject
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var PlaneTypeList = [String : PlaneType]()
    
    init() {
        self.loadPlaneTypeData()
    }
    
    func loadPlaneTypeData(){
        PlaneTypeList = [:]
        
        let p1 = PlaneType(planeTypeId: "A111", discription: "2 engines, single aisle, originally Bombardier CSeries", noOfSeats: 130, planeName: PlaneTypeCategory.Airbus)
            PlaneTypeList[p1.PlaneTypeId!] = p1
        
        let p2 = PlaneType(planeTypeId: "A112", discription: "They are short- to medium-range, narrow-body jet airliners powered by two engines.", noOfSeats: 120, planeName: PlaneTypeCategory.Boeing)
        PlaneTypeList[p2.PlaneTypeId!] = p2
        
        let p3 = PlaneType(planeTypeId: "A113", discription: "2 engines, single aisle, originally Bombardier CSeries", noOfSeats: 128, planeName: PlaneTypeCategory.Bombardier)
        PlaneTypeList[p3.PlaneTypeId!] = p3
        
        let p4 = PlaneType(planeTypeId: "A114", discription: "2 engines, single aisle, originally Bombardier CSeries", noOfSeats: 140, planeName: PlaneTypeCategory.Textron)
        PlaneTypeList[p4.PlaneTypeId!] = p4
        
        let p5 = PlaneType(planeTypeId: "A115", discription: "2 engines, single aisle, originally Bombardier CSeries", noOfSeats: 110, planeName: PlaneTypeCategory.Spirit)
        PlaneTypeList[p5.PlaneTypeId!] = p5
    }
    
    func displayPlaneType(){
        print("Plane tyoe details")
        Util.drawLine()
        print("\t ID \t\t Discription \t\t\t\t  No of seats \t\t PlaneType Name")
        for (_, value) in self.PlaneTypeList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.PlaneTypeId!) ------ \(value.Discription!) ------ \(value.NoOfSeats!) ------ \(value.PlaneName!)")
        }
        Util.drawLine()
    }
    
//    func displayPlaneType(){
//        //closures
//        for (_,plane) in PlaneTypeList.sorted(by: {$0.key < $1.key}){
//            print("\(plane.displayData())")
//        }
//    }
    
}
