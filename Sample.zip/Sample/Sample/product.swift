//
//  product.swift
//  Sample
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Product : IDisplay {
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Product ID : \(self.ProductId ?? 0)"
        returnData += "\n Product Name : \(self.ProductName ?? "")"
        returnData += "\n Manufacturer : \(self.manufacturer ?? "")"
        returnData += "\n Unit price : \(self.unitPrice ?? 0.0)"
        returnData += "\n Category : \(self.Category ?? ProductCategory.None)"
        return returnData
    }
    
    func newProduct(){
        print("Select the following product category")
        for category in ProductCategory.allCases {
            print("Enter \(category.rawValue) for \(category)")
        }
        let choice = (Int)(readLine()!)
        self.category = ProductCategory(rawValue: choice!)
        print("Enter id : ")
        self.productId = (Int)(readLine()!)
        print("Enter name : ")
        self.productName = (String)(readLine()!)
        print("Enter Manufacturer : ")
        self.manufacturer = (String)(readLine()!)
        print("Enter Unit price : ")
        self.unitPrice = (Double)(readLine()!)
        
    
}
    
    
    
    var productId : Int?
    var productName : String?
    var manufacturer : String?
    var unitPrice : Double?
    var category : ProductCategory?
    
    
        var ProductId : Int? {
        get{ return self.productId}
        set{ self.productId = newValue}
        }
    
        var ProductName : String? {
            get{ return self.productName}
            set{ self.productName = newValue}
        }
    
        var Manufacturer : String? {
            get{ return self.manufacturer}
            set{ self.manufacturer = newValue}
        }
        
        var UnitPrice : Double? {
            get{ return self.unitPrice}
            set{ self.unitPrice = newValue}
        }
    
        var Category : ProductCategory? {
            get{ return self.category}
            set{ self.category = newValue}
        }
    
    
    init(){
        self.productId = 0
        self.productName = ""
        self.manufacturer = ""
        self.unitPrice = 0.0
        self.category = ProductCategory.None
    }
    
    init(productId: Int, productName: String, manufecturer: String, unitPrice: Double, category: ProductCategory){
        
        self.productId = productId
        self.productName = productName
        self.manufacturer = manufecturer
        self.unitPrice = unitPrice
    }
    
}
