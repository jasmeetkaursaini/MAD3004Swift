//
//  DataHelper.swift
//  Sample
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper {
    var ProductList = [Int : Product]()
    init() {
        self.loadProducts()
    }
    
    func loadProducts(){

        let epson = Product(productId: 101, productName: "Projector", manufecturer: "Epson", unitPrice: 1000.1, category: ProductCategory.Appliances)
        ProductList[epson.ProductId!] = epson
        
        let handcream = Product(productId: 101, productName: "Handcream", manufecturer: "Glysomed", unitPrice: 12.23, category: ProductCategory.Health)
        ProductList[handcream.ProductId!] = handcream
        
        let flask = Product(productId: 102, productName: "Flask", manufecturer: "Contigo", unitPrice: 20, category: ProductCategory.Appliances)
        ProductList[flask.ProductId!] = flask
        
        let zelda = Product(productId: 103, productName: "The Legend of Zelda", manufecturer: "Nintendo", unitPrice: 27.97, category: ProductCategory.Books)
        ProductList[zelda.ProductId!] = zelda
        
        let sapiens = Product(productId: 104, productName: "Sapiens", manufecturer: "Yuval Noah Harari", unitPrice: 11.89, category: ProductCategory.Books)
        ProductList[sapiens.ProductId!] = sapiens
        
        let socks = Product(productId: 105, productName: "Puma Men's 6 pack Low Cut Socks", manufecturer: "Puma", unitPrice: 23.40, category: ProductCategory.Clothing)
        ProductList[socks.ProductId!] = socks
        
        let dress = Product(productId: 106, productName: "Women's Vintage Floral Cocktail Dress", manufecturer: "OWIN", unitPrice: 45, category: ProductCategory.Clothing)
        ProductList[dress.ProductId!] = dress
        
    }
    
        func displayProducts(){
            for (_,value) in ProductList.sorted(by: {$0.key < $1.key}) {
                print("\(value.displayData())")
            }
    }
}
