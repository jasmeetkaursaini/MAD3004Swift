//
//  ViewController.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var switchRemember: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let email = UserDefaults.standard.value(forKey: txtEmail.text!) {
            //txtEmail.text = email as? String
        }
//        if let password = UserDefaults.standard.value(forKey: "password") {     //value will return the value as Any and have to do the type casting before.
//            txtPassword.text = password as? String
//        }
        
//        if let password = UserDefaults.standard.string(forKey: "password") {
//            txtPassword.text = password
//        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnSignUp(_ sender: UIButton) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signUpVC = mainSB.instantiateViewController(withIdentifier: "SignUpScene")
        navigationController?.pushViewController(signUpVC, animated: true)
    }
    
    @IBAction func btnSignIn(_ sender: UIButton) {
        if validateUser(){
            
            if switchRemember.isOn {
            //save the data
//                UserDefaults.standard.set(txtEmail.text!, forKey: "email")
//                UserDefaults.standard.set(txtPassword.text!, forKey: "password")
                UserDefaults.standard.set(txtPassword.text!, forKey: txtEmail.text!)
            }else{
                UserDefaults.standard.removeObject( forKey: txtEmail.text!)
                //UserDefaults.standard.removeObject(forKey: "password")
            }

            
            //open home screen
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
//            self.present(homeVC, animated: true, completion: nil)
            navigationController?.pushViewController(homeVC, animated: true)
            
        }else{
            //display alert message
            let infoAlert = UIAlertController(title: "User Account", message: "Invalid Email and/or Password", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: nil))
//            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//            infoAlert.addAction(UIAlertAction(title: "Don't bother me", style: .destructive, handler: nil))
//            infoAlert.addAction(UIAlertAction(title: "Oh really !!", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true, completion: nil)
        }
    }
    
    func validateUser() -> Bool{
        if txtEmail.text == "test" && txtPassword.text == "test"{
            return true
        }else{
            return false
        }
    }
}
















