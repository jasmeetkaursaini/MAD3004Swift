//
//  main.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var request1 = RequestlimitIncrease()
var request2 = RequestlimitIncrease()
var request3 = RequestlimitIncrease()

do{
    //try request3.processRequest(accountNo: "S1200")
    try request2.processRequest(accountNo: "S1400")
    try request1.processRequest(accountNo: "S1100")
}catch LimitIncreaseError.ineligible{
    print("No account")
}catch LimitIncreaseError.noSavingAc{
    print("Limit will increase if you have saving AC")
}catch LimitIncreaseError.insufficientBalance{
    print("Need min $5000 to increase credit limit")
}catch{
    print("Service distrupted...")
}


//do{
//    try request1.processRequest(accountNo: "S1200")
//}catch is LimitIncreaseError{
//    print("Not matching any criteria")
//    print("1. ,2.")
//}

//Static
var s1 = Student()
s1.name = "Rutvi"
//Student.acNo = 978   //'acNo' is inaccessible due to 'private' protection level
s1.display()

var s2 = Student()
s2.name = "Foram"
s2.display()
