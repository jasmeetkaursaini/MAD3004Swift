//
//  RequestLimitIncrease.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class RequestlimitIncrease{
    var accountInfo = [
        "S1100" : AcInfo(type: "Saving", balance: 2313.54),
        "S1200" : AcInfo(type: "Cheqing", balance: 4500.55),
        "S1300" : AcInfo(type: "Cheqing", balance: 5310.20),
        "S1400" : AcInfo(type: "Saving", balance: 7313.44)
    ]
    
    func processRequest(accountNo: String) throws {
        guard let accNo = accountInfo[accountNo]    //quite similar to if statement
            else{
            throw LimitIncreaseError.ineligible
        }
        guard accNo.type == "Saving"
            else{
            throw LimitIncreaseError.noSavingAc
        }
        guard accNo.balance >= 5000
            else{
            throw LimitIncreaseError.insufficientBalance
        }
        print("Congratulations..! Your credit limit is incresed")
    }
    
}

struct AcInfo {
    var type : String
    var balance : Double
}

enum LimitIncreaseError: Error {
    case ineligible
    case noSavingAc
    case insufficientBalance
}
